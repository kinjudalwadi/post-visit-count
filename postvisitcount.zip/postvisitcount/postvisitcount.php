<?php

/*
Plugin Name: Post Visit Count
Plugin URI: https://profiles.wordpress.org/kinjaldalwadi/#content-plugins
Description: This plugin is used for view post visitor.
Version: 4.1.8
Author: Kinjal Dalwadi
Author URI: https://profiles.wordpress.org/kinjaldalwadi/
License: GPLv2 or later
Text Domain: postvisitcount
*/

/* THIS FUNCTION RETURS NUMBER OF VIEWS FOR A POST */
function PVC_count_result(){
    $postID = get_the_ID();
    $count_key = 'pvc_post_views_count_results';
    $count = get_post_meta($postID, $count_key, true);
    if($count==''){
          delete_post_meta($postID, $count_key);
          add_post_meta($postID, $count_key, '1');
          return 1;
    }
    if(intval($count) > 1000){
         return number_format($count/1000,1).'K';
    }elseif(intval($count) > 1000000){
         return number_format($count/1000000,1).'M';
    }else{
         return $count;
    }
}

/* This Function counts POST Views */
function PVC_setPost_View_Count() {
    $postID = get_the_ID();
    $count_key = 'pvc_post_views_count_results';
    $count = get_post_meta($postID, $count_key, true);
    if($count==''){
        $count = 0;
        delete_post_meta($postID, $count_key);
        add_post_meta($postID, $count_key, '0');
    }else{
        $count++;
        update_post_meta($postID, $count_key, $count);
    }
}


function PVC_single_file_result( $content ) {
    if ( is_single() ) {
        $custom_contents = '<h5 style="color:green">'.PVC_count_result().' Views'.'</h5>';
        $custom_contents .= $content;
		return $custom_contents;
    } else {
        return $content;
    }      
}
add_filter( 'the_content', 'PVC_single_file_result' );

