=== Post visit count ===
Contributors: kinjaldalwadi
Requires at least: 4.6
Tested up to: 5.6
Stable tag: 4.1.8
License: GPLv2 or later


== Description ==
This plugin count total views of blog post and display before the content without adding any code.It will work by just activation of plugin.